exports.handler = async (event, context) => {
  const body = JSON.parse(event.body || '{}');
  const password = body.password;

  // Mot de passe sécurisé côté serveur
  const SECURE_PASSWORD = '271263';

  if (password === SECURE_PASSWORD) {
    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } else {
    return { statusCode: 200, body: JSON.stringify({ success: false }) };
  }
};
